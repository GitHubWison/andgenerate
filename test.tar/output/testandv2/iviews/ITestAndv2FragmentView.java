/**
 * Created by xuqiwei on 2017年06月10日.
 */
public interface ITestAndv2FragmentView {
}

